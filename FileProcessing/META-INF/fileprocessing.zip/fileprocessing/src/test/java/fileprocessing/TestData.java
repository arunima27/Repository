package fileprocessing;

import org.json.JSONArray;
import org.json.JSONObject;

public class TestData {
	public JSONObject main(){
	
	JSONObject obj = new JSONObject();

      obj.put("Company", "HCL");
      obj.put("FirstName", "JKL");
      obj.put("Email", "jkl@jkl.com");
      obj.put("LastName", "ZZZ");
	JSONObject obj1 = new JSONObject();

	 obj1.put("Company", "NIIT");
      obj1.put("FirstName", "DEF");
      obj1.put("Email", "def@def.com");
      obj1.put("LastName", "MMM");
      
      JSONObject obj2 = new JSONObject();

		 obj2.put("Company", "HCL Tech");
	      obj2.put("FirstName", "ABC");
	      obj2.put("Email", "abc@abc.com");
	      obj2.put("LastName", "GGG");

      JSONArray ja = new JSONArray();
      ja.put(obj);
      ja.put(obj1);
      ja.put(obj2);

      JSONObject mainObj = new JSONObject();
      mainObj.put("Records", ja);
      
      return mainObj;

}

}

